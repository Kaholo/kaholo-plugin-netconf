"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Notification {
    constructor(data, raw) {
        this.data = data;
        this.raw = raw;
    }
}
exports.default = Notification;
